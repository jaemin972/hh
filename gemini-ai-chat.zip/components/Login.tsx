import React from 'react';
import useAuth from '../hooks/useAuth';

const Login: React.FC = () => {
    const { login } = useAuth();

    return (
        <div className="flex items-center justify-center h-screen bg-gray-900">
            <div className="text-center p-10 bg-gray-800 rounded-xl shadow-2xl border border-gray-700">
                <h1 className="text-4xl font-bold text-white mb-2">Welcome to Gemini Chat</h1>
                <p className="text-gray-400 mb-8">Sign in to start your conversation with AI.</p>
                <button
                    onClick={login}
                    className="px-6 py-3 bg-cyan-600 text-white font-semibold rounded-lg hover:bg-cyan-700 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:ring-opacity-50"
                >
                    Sign In as Demo User
                </button>
            </div>
        </div>
    );
};

export default Login;