import React from 'react';
import { ChatMessage } from '../types';
import LoadingSpinner from './LoadingSpinner';

interface MessageProps {
    message: ChatMessage;
    isLoading?: boolean;
}

const ModelIcon: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-8 h-8 text-cyan-400">
        <path fillRule="evenodd" d="M4.5 3.75a3 3 0 0 0-3 3v10.5a3 3 0 0 0 3 3h15a3 3 0 0 0 3-3V6.75a3 3 0 0 0-3-3h-15Zm4.125 3a2.25 2.25 0 1 0 0 4.5 2.25 2.25 0 0 0 0-4.5Zm-3.873 8.703a.75.75 0 0 0 1.06 1.06l2.122-2.121a.75.75 0 0 0-1.06-1.06l-2.122 2.12Zm5.197-1.06a.75.75 0 0 0-1.06-1.06l-2.121 2.12a.75.75 0 0 0 1.06 1.06l2.121-2.12ZM16.5 6.75a.75.75 0 0 1 .75.75v3a.75.75 0 0 1-1.5 0v-3a.75.75 0 0 1 .75-.75Zm2.25 0a.75.75 0 0 1 .75.75v3a.75.75 0 0 1-1.5 0v-3a.75.75 0 0 1 .75-.75Z" clipRule="evenodd" />
    </svg>
);

const UserIcon: React.FC = () => (
     <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-8 h-8 text-gray-400">
        <path fillRule="evenodd" d="M18.685 19.097A9.723 9.723 0 0 0 21.75 12c0-5.385-4.365-9.75-9.75-9.75S2.25 6.615 2.25 12a9.723 9.723 0 0 0 3.065 7.097A9.716 9.716 0 0 0 12 21.75a9.716 9.716 0 0 0 6.685-2.653Zm-12.54-1.285A7.486 7.486 0 0 1 12 15a7.486 7.486 0 0 1 5.855 2.812A8.224 8.224 0 0 1 12 20.25a8.224 8.224 0 0 1-5.855-2.438ZM15.75 9a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0Z" clipRule="evenodd" />
    </svg>
);


const Message: React.FC<MessageProps> = ({ message, isLoading = false }) => {
    const isModel = message.role === 'model';

    return (
        <div className={`flex items-start gap-4 ${!isModel && 'flex-row-reverse'}`}>
            <div className="flex-shrink-0">
                {isModel ? <ModelIcon /> : <UserIcon />}
            </div>
            <div className={`w-fit max-w-lg lg:max-w-2xl px-5 py-3 rounded-2xl ${isModel ? 'bg-gray-800 rounded-bl-none' : 'bg-cyan-800 rounded-br-none'}`}>
                {isLoading ? (
                    <div className="flex items-center justify-center">
                        <LoadingSpinner />
                    </div>
                ) : (
                    <p className="text-white whitespace-pre-wrap">{message.parts[0].text}</p>
                )}
            </div>
        </div>
    );
};

export default Message;
