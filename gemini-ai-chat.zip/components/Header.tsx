
import React from 'react';
import useAuth from '../hooks/useAuth';

const Header: React.FC = () => {
  const { user, logout } = useAuth();

  if (!user) return null;

  return (
    <header className="flex items-center justify-between p-4 bg-gray-800 border-b border-gray-700 shadow-md">
      <div className="flex items-center">
        <img src={user.picture} alt={user.name} className="w-10 h-10 rounded-full mr-4 border-2 border-cyan-400" />
        <div>
          <h1 className="text-lg font-semibold text-white">{user.name}</h1>
          <p className="text-sm text-gray-400">{user.email}</p>
        </div>
      </div>
      <button
        onClick={logout}
        className="px-4 py-2 bg-red-600 text-white font-semibold rounded-lg hover:bg-red-700 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-opacity-50"
      >
        Logout
      </button>
    </header>
  );
};

export default Header;
